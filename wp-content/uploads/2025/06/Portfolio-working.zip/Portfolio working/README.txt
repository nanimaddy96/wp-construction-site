# Portfolio Theme

## Overview
This is a modern WordPress theme with full site editing support, clean semantic markup, and a focus on showcasing projects and personal information.

## Features
- Custom background, logo, and menu support
- Featured images
- Block styles and full site editing
- Responsive and modern design

## Structure
- `parts/`: Reusable HTML components (header, footer)
- `patterns/`: PHP functions for reusable patterns (e.g., project cards)
- `styles/`: Style configurations for the theme
- `templates/`: Template files for different pages (index, archive, 404)

## Installation
1. Upload the theme folder to `/wp-content/themes/`
2. Activate the theme through Appearance > Themes in the WordPress admin panel

## Usage
- Customize the theme by modifying the HTML, CSS, and PHP files as needed.

## Files
- `index.html`: Main homepage template
- `archive.html`: Archive template for listing projects or blog posts
- `singular.html`: Template for individual posts/pages
- `404.html`: Error 404 page template
- `functions.php`: PHP functions for the theme
- `style.css`: Main stylesheet
- `theme.json`: Theme configuration file for block editor styles

## Changelog
### 1.0
* Initial release

## Credits
Created by [Your Name].
