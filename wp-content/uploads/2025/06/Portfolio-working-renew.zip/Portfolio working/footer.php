<?php
// Standard WordPress footer
?>
<?php wp_footer(); ?>
</body>
</html> 