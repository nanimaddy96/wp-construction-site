<?php get_header(); ?>
<section class="error-section">
  <div class="container">
    <h1>Oops! Page Not Found</h1>
    <p>The page you are looking for does not exist.</p>
    <a href="#" class="btn">Go Back Home</a>
  </div>
</section>
<?php get_footer(); ?>