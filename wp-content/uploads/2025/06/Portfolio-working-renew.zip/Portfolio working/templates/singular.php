<?php get_header(); ?>
<section class="singular-section">
  <div class="container">
    <h1><?php echo get_the_title(); ?></h1>
    <div class="content">
      <?php the_content(); ?>
    </div>
  </div>
</section>
<?php get_footer(); ?>