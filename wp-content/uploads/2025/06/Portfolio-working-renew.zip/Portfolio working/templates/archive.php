<?php get_header(); ?>
<section class="archive-section">
  <div class="container">
    <h1>Archive</h1>
    <div class="projects">
      <?php
      // Example data for projects
      $projects = [
        [
          'title' => 'Project 1',
          'description' => 'Description of Project 1',
          'image_url' => 'path/to/image1.jpg'
        ],
        [
          'title' => 'Project 2',
          'description' => 'Description of Project 2',
          'image_url' => 'path/to/image2.jpg'
        ]
      ];
      foreach ($projects as $project) {
        render_project_card($project['title'], $project['description'], $project['image_url']);
      }
      ?>
    </div>
  </div>
</section>
<?php get_footer(); ?>